document.addEventListener('DOMContentLoaded', function() {
    const cartList = document.getElementById('cart-list');
    const totalPriceElement = document.getElementById('total-price');

    // Carregar o carrinho do localStorage
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Função para exibir os produtos no carrinho
    function displayCart() {
        cartList.innerHTML = '';
        let totalPrice = 0;

        cart.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';
            productDiv.innerHTML = `
                <img src="${product.imagem}" alt="${product.nome}">
                <h3>${product.nome}</h3>
                <p>${product.descricao}</p>
                <p><strong>R$${product.preco.toFixed(2)}</strong></p>
            `;
            cartList.appendChild(productDiv);
            totalPrice += product.preco;
        });

        // Atualizar o preço total
        totalPriceElement.textContent = totalPrice.toFixed(2);
    }

    displayCart();
});