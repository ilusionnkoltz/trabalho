document.getElementById("formCadastro").addEventListener("submit", function(evento) {
    evento.preventDefault(); // evita que a página seja recarregada

    // captura os valores
    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const idade = parseInt(document.getElementById("idade").value);

    const mensagem = document.getElementById("mensagem");

    // validações
    if (nome === "") {
        mensagem.textContent = "Por favor, preencha o nome.";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        mensagem.textContent = "E-mail inválido.";
        return;
    }

    if (isNaN(idade) || idade < 18) {
        mensagem.textContent = "Idade mínima é 18 anos.";
        return;
    }

    // se tudo estiver ok
    mensagem.style.color = "green";
    mensagem.textContent = "Formulário enviado com sucesso!";
});
