document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search');
    const minPriceInput = document.getElementById('min-price');
    const maxPriceInput = document.getElementById('max-price');
    const productList = document.getElementById('product-list');

    // Carregar os produtos inicialmente
    fetch('produtos.json')
        .then(response => response.json())
        .then(data => displayProducts(data));

    // Filtrar produtos com base na pesquisa e no intervalo de preço
    function filterProducts() {
        fetch('produtos.json')
            .then(response => response.json())
            .then(data => {
                const query = searchInput.value.toLowerCase();
                const minPrice = parseFloat(minPriceInput.value) || 0;
                const maxPrice = parseFloat(maxPriceInput.value) || Infinity;

                const filteredData = data.filter(product => {
                    const isNameMatch = product.nome.toLowerCase().includes(query);
                    const isPriceMatch = product.preco >= minPrice && product.preco <= maxPrice;
                    return isNameMatch && isPriceMatch;
                });
                displayProducts(filteredData);
            });
    }

    searchInput.addEventListener('keyup', filterProducts);
    minPriceInput.addEventListener('input', filterProducts);
    maxPriceInput.addEventListener('input', filterProducts);


    // Função para exibir os produtos filtrados
    function displayProducts(products) {
        productList.innerHTML = '';
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';

            // Obter a média de avaliações para o produto
            const averageRating = getAverageRating(product.id);

            productDiv.innerHTML = `
                <img src="${product.imagem}" alt="${product.nome}">
                <h3>${product.nome}</h3>
                <p>${product.descricao}</p>
                <p><strong>R$${product.preco.toFixed(2)}</strong></p>
                <div class="rating" data-product-id="${product.id}">
                    ${renderStars(product.id, averageRating)}
                </div>
                <p>Média de Avaliações: <span id="average-rating-${product.id}">${averageRating.toFixed(1)}</span></p>
                <button onclick="window.addToCart(${product.id})">Adicionar ao Carrinho</button>
            `;
            productList.appendChild(productDiv);
        });

        // Adicionar eventos de clique para as estrelas
        const starElements = productList.querySelectorAll('.star');
        starElements.forEach(star => {
            star.addEventListener('click', () => handleRating(star.dataset.productId, star.dataset.rating));
        });
    }

    // Função para renderizar as estrelas
    function renderStars(productId, averageRating) {
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            const starClass = i <= averageRating ? 'star filled' : 'star';
            starsHtml += `<span class="${starClass}" data-rating-id="${i}" data-product-id="${productId}">&#9733;</span>`;
        }
        return starsHtml;
    }

    // Função para tratar a avaliação do produto
    function handleRating(productId, rating) {
        let ratings = JSON.parse(localStorage.getItem('ratings')) || {};

        if (!ratings[productId]) {
            ratings[productId] = [];
        }
        ratings[productId].push(Number(rating));
        localStorage.setItem('ratings', JSON.stringify(ratings));

        // Atualizar a média de avaliação do produto
        const averageRating = getAverageRating(productId);
        document.getElementById(`average-rating-${productId}`).textContent = averageRating.toFixed(1);

        // Re-renderizar as estrelas para refletir a nova média
        const starsContainer = document.querySelector(`.rating[data-product-id="${productId}"]`);
        starsContainer.innerHTML = renderStars(productId, averageRating);
    }

    // Função para obter a média de avaliações de um produto
    function getAverageRating(productId) {
        const ratings = JSON.parse(localStorage.getItem('ratings')) || {};
        const productRatings = ratings[productId] || [];
        const total = productRatings.reduce((sum, rating) => sum + rating, 0);
        return productRatings.length ? total / productRatings.length : 0;
    }

    // Função para adicionar um produto ao carrinho
    window.addToCart = function(productId) {
        fetch('produtos.json')
            .then(response => response.json())
            .then(data => {
                const product = data.find(p => p.id === productId);
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
                cart.push(product);
                localStorage.setItem('cart', JSON.stringify(cart));
                alert(`${product.nome} foi adicionado ao carrinho!`);
            });
    };
});