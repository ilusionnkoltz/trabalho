// Funções para gerenciar as tarefas

// Função para adicionar tarefa à lista de tarefas
function adicionarTarefa(descricao, concluida) {
    const novaTarefa = document.createElement('li');
    novaTarefa.textContent = descricao;
    if (concluida) {
        novaTarefa.classList.add('tarefa-concluida');
    }
    
    novaTarefa.addEventListener('click', function() {
        novaTarefa.classList.toggle('tarefa-concluida');
        atualizarTarefaLocal(descricao, novaTarefa.classList.contains('tarefa-concluida'));
    });
    
    document.getElementById('listaTarefas').appendChild(novaTarefa);
}

// Função para salvar uma nova tarefa no Local Storage
function salvarTarefaLocal(descricao, concluida) {
    const tarefasLocalStorage = JSON.parse(localStorage.getItem('tarefas')) || [];
    tarefasLocalStorage.push({ descricao, concluida });
    localStorage.setItem('tarefas', JSON.stringify(tarefasLocalStorage));
}

// Função para atualizar o status de uma tarefa no Local Storage
function atualizarTarefaLocal(descricao, concluida) {
    const tarefasLocalStorage = JSON.parse(localStorage.getItem('tarefas')) || [];
    const tarefa = tarefasLocalStorage.find(t => t.descricao === descricao);
    if (tarefa) {
        tarefa.concluida = concluida;
        localStorage.setItem('tarefas', JSON.stringify(tarefasLocalStorage));
    }
}

// Função para carregar tarefas do JSON e Local Storage
function carregarTarefas() {
    fetch('tarefas.json')
        .then(response => response.json())
        .then(data => {
            // Carregar tarefas do JSON
            data.forEach(tarefa => {
                adicionarTarefa(tarefa.descricao, tarefa.concluida);
            });
            
            // Carregar tarefas do Local Storage
            const tarefasLocalStorage = JSON.parse(localStorage.getItem('tarefas')) || [];
            tarefasLocalStorage.forEach(tarefa => {
                adicionarTarefa(tarefa.descricao, tarefa.concluida);
            });
        })
        .catch(error => console.error('Erro ao carregar o arquivo JSON:', error));
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    carregarTarefas();
});

document.getElementById('formTarefa').addEventListener('submit', function(e) {
    e.preventDefault();
    const tarefa = document.getElementById('entradatarefa').value;
    if (tarefa.trim() !== '') {
        adicionarTarefa(tarefa, false);
        salvarTarefaLocal(tarefa, false);
        document.getElementById('entradatarefa').value = '';
    }
});