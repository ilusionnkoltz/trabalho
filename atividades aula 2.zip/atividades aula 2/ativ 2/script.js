const itemInput = document.getElementById("itemInput");
const imgInput = document.getElementById("imgInput");
const addBtn = document.getElementById("addBtn");
const itemList = document.getElementById("itemList");

addBtn.addEventListener("click", () => {
  const text = itemInput.value.trim();
  const imgUrl = imgInput.value.trim();

  if (text === "") {
    alert("Digite um item!");
    return;
  }

  const li = document.createElement("li");

  // Se tiver imagem, adiciona
  if (imgUrl) {
    const img = document.createElement("img");
    img.src = imgUrl;
    img.alt = text;
    li.appendChild(img);
  }

  // Texto do item
  const span = document.createElement("span");
  span.textContent = text;
  li.appendChild(span);

  // Botão de remover
  const removeBtn = document.createElement("button");
  removeBtn.textContent = "X";
  removeBtn.classList.add("removeBtn");
  removeBtn.addEventListener("click", () => {
    itemList.removeChild(li);
  });
  li.appendChild(removeBtn);

  // Adiciona na lista
  itemList.appendChild(li);

  // Limpa campos
  itemInput.value = "";
  imgInput.value = "";
});
