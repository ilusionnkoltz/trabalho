const botao = document.getElementById("converter");
const campoValor = document.getElementById("valor");
const resultado = document.getElementById("resultado");

// Cotação fixa para o dólar
const cotacaoDolar = 5.20;

botao.addEventListener("click", function () {
    const valorEmReais = parseFloat(campoValor.value);

    if (isNaN(valorEmReais) || valorEmReais <= 0) {
        resultado.style.color = "red";
        resultado.textContent = "Digite um valor válido maior que zero.";
        return;
    }

    const valorConvertido = valorEmReais / cotacaoDolar;

    resultado.style.color = "green";
    resultado.textContent = `Com R$ ${valorEmReais.toFixed(2)}, você tem aproximadamente US$ ${valorConvertido.toFixed(2)}.`;
});
